import React from "react";
 import "./Dashboard.css";

const Dashboard = () => {
    return (
        <div>Dashobard page  and your logged in</div>
    );
};

export default Dashboard;