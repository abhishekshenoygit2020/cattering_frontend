import React from 'react';
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Radio from '@mui/material/Radio';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import Grid from '@mui/material/Grid';

function Program3() {
  return (
    <div>
      <h2>Responsive Form</h2>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={12} md={6} lg={12}>
          <TextField variant='outlined' fullWidth />
          </Grid>
          <Grid item xs={12} sm={12} md={6} lg={12}>
          <TextField variant='outlined' fullWidth />
          </Grid>
          <Grid item xs={12} sm={12} md={12} lg={12}>
          <FormControlLabel control={<Radio />} label="Radio Example" />
          </Grid>
          <Grid item xs={12}>
          <FormControlLabel control={<Checkbox />} label="Checkbox Example" />
          </Grid>
          <Grid item xs={12} sm={12} md={12} lg={12}>
          <Button variant="contained">Contained</Button>
          </Grid>
        </Grid>
    </div>
  );
}

export default Program3;
//xs (for phones - screens less than 768px wide) <768
//sm (for tablets - screens equal to or greater than 768px wide) >=768
//md (for small laptops - screens equal to or greater than 992px wide) >=992
//lg (for laptops and desktops - screens equal to or greater than 1200px wide) >=1200
//container spacing ={2}=>spacing between textbox button .