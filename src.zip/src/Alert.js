import React from 'react';
import { Grid, Paper, TextField, Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';


function Alert() {
    const navigate = useNavigate(); 

  const handleSubmit = () => {
    alert("succefully registered");
    navigate('/Dashboard');
  };

  return (
    <div>
      <h2>Sample Form with Grid</h2>
      <Paper elevation={3} style={{ padding: '20px' }}>
        <Grid container spacing={2}>
          {/* Grid item 1 */}
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Name"
              variant="outlined"
              // Add your input field props here
            />
          </Grid>

          {/* Grid item 2 */}
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Email"
              variant="outlined"
              // Add your input field props here
            />
          </Grid>

          {/* Grid item 3 */}
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Message"
              variant="outlined"
              multiline
              rows={4}
              // Add your input field props here
            />
          </Grid>

          {/* Grid item 4 */}
          <Grid item xs={12}>
          <Button
          variant="contained"
          color="primary"
          onClick={handleSubmit} // Call handleSubmit on button click
        >
          Submit
        </Button>
          </Grid>
        </Grid>
      </Paper>
    </div>
  );
}

export default Alert;