import React from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';

function Program4() {

   const navigate = useNavigate(); 
   const handleSubmit = () => {
    navigate('/Dashboard');
  };

  return (
    <div>
      <h2>Navigate Demo</h2>
            <Button variant="contained" color="primary" onClick={handleSubmit}>
              Submit
            </Button>

    </div>
  );
}

export default Program4;