import React, { useState } from "react";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";

function App() {
  const [number1, setNumber1] = useState("");
  const [number2, setNumber2] = useState("");
  const [sum, setSum] = useState("");
  const [error, setError] = useState("");

  function addition() {
    // Check if the input values are empty
    if (number1 === "" || number2 === "") {
      setError("Please fill in both numbers");
      setSum("");
    } else if (!isNaN(number1) && !isNaN(number2)) {
      setSum(parseInt(number1) + parseInt(number2));
      setError(""); // Clear any previous error
    } else {
      setError("Please enter valid numbers"); // Set an error message
      setSum(""); // Clear the sum
    }
  }

  return (
    <div style={{ width: 500, margin: 25 }}>
      <TextField
        variant="outlined"
        placeholder="Enter first number"
        type="number"
        fullWidth
        value={number1}
        onChange={(e) => setNumber1(e.target.value)}
      />
      <TextField
        style={{ marginTop: 25 }}
        variant="outlined"
        placeholder="Enter second number"
        type="number"
        fullWidth
        value={number2}
        onChange={(e) => setNumber2(e.target.value)}
      />
      <Button
        style={{ marginTop: 25 }}
        fullWidth
        variant="contained"
        onClick={addition}
      >
        Click Me
      </Button>
      <p>{error}</p>
      {sum !== "" && <p>Sum: {sum}</p>}
    </div>
  );
}

export default App;