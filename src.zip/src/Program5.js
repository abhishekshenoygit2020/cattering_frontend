import React from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';

function Program5() {
   const navigate = useNavigate(); 
   const handleSubmit = () => {
    alert("succefully registered");
    navigate('/Dashboard');
  };


  return (
    <div>
      <h2>Sample Form with Grid</h2>
            <Button variant="contained" color="primary" onClick={handleSubmit}>
              Submit
            </Button>
    </div>
  );
}

export default Program5;