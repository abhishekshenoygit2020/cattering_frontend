import React from 'react';
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Radio from '@mui/material/Radio';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import Grid from '@mui/material/Grid';

function Program1() {
  return (
    <Grid container spacing={2}>
      <Grid item xs={12} sm={6} md={4} lg={3}>
        <Button variant="contained">Contained</Button>
      </Grid>
      <Grid item xs={12} sm={6} md={4} lg={3}>
        <TextField variant='outlined' fullWidth />
      </Grid>
      <Grid item xs={12} sm={6} md={4} lg={3}>
        <FormControlLabel control={<Radio />} label="Radio Example" />
      </Grid>
      <Grid item xs={12} sm={6} md={4} lg={3}>
        <FormControlLabel control={<Checkbox />} label="Checkbox Example" />
      </Grid>
    </Grid>
  );
}

export default Program1;