import React, { useState } from 'react';

function Calculator() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [result, setResult] = useState('');

  const handleAdd = () => {
    const parsedNum1 = parseFloat(num1);
    const parsedNum2 = parseFloat(num2);

    if (!isNaN(parsedNum1) && !isNaN(parsedNum2)) {
      const sum = parsedNum1 + parsedNum2;
      setResult(`Result: ${sum}`);
    } else {
      setResult('Invalid input. Please enter valid numbers.');
    }
  };

  return (
    <div>
      <h2>Add Two Numbers</h2>
      <div>
        <label>Number 1:</label>
        <input
          type="text"
          value={num1}
          onChange={(e) => setNum1(e.target.value)}
        />
      </div>
      <div>
        <label>Number 2:</label>
        <input
          type="text"
          value={num2}
          onChange={(e) => setNum2(e.target.value)}
        />
      </div>
      <button onClick={handleAdd}>Add</button>
      <div>
        <label>{result}</label>
      </div>
    </div>
  );
}

export default Calculator;

