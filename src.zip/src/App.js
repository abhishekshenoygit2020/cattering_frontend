import React from 'react';
import { BrowserRouter as Router, Form, Route, Routes } from 'react-router-dom';
import { Container } from '@mui/material';
import Program1 from './Program1';
import Program2 from './Program2';
import Program3 from './Program3';
import Program4 from './Program4';
import Program5 from './Program5';
import Dashboard from './Dashboard';


function App() {
  return (
    <>
    {/* <Form/> */}
    
    <Router>
      <Container maxWidth="md">
        <Routes>

          <Route path="/Program1" element={<Program1/>} />
          <Route path="/Program2" element={<Program2/>} />
          <Route path="/Program3" element={<Program3/>} />
          <Route path="/Program4" element={<Program4/>} />
          <Route path="/Program5" element={<Program5/>} />

          <Route path="/Dashboard" element={<Dashboard/>} />

        </Routes>
      </Container>
    </Router>
    </>
  );
}

export default App;

//routing ->keep your application in sync with the browser URL
//browserrouter -it allows broswer to change the url