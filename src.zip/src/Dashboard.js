import React from 'react';

function Dashboard() {
  return (
    <div>
      <h2>welcome to workshop</h2>
    </div>
  );
}

export default Dashboard;